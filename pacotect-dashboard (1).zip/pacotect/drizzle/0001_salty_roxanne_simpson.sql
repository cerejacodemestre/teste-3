CREATE TABLE `parcel_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`packageCode` varchar(120) NOT NULL,
	`huCode` varchar(120) NOT NULL,
	`cptAt` varchar(19) NOT NULL,
	`location` varchar(120) NOT NULL,
	`channel` varchar(120) NOT NULL,
	`stage` varchar(120) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `parcel_events_id` PRIMARY KEY(`id`),
	CONSTRAINT `parcel_events_package_cpt_unique` UNIQUE(`packageCode`,`cptAt`)
);
--> statement-breakpoint
CREATE INDEX `parcel_events_cpt_idx` ON `parcel_events` (`cptAt`);--> statement-breakpoint
CREATE INDEX `parcel_events_location_idx` ON `parcel_events` (`location`);