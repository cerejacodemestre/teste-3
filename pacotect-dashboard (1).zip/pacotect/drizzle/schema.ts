import { int, index, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/** Core user table backing the optional auth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** One operational snapshot row per parcel and CPT timestamp. */
export const parcelEvents = mysqlTable(
  "parcel_events",
  {
    id: int("id").autoincrement().primaryKey(),
    packageCode: varchar("packageCode", { length: 120 }).notNull(),
    huCode: varchar("huCode", { length: 120 }).notNull(),
    // Keep CPT as a local wall-clock value so Brazilian operation times do not shift by timezone.
    cptAt: varchar("cptAt", { length: 19 }).notNull(),
    location: varchar("location", { length: 120 }).notNull(),
    channel: varchar("channel", { length: 120 }).notNull(),
    stage: varchar("stage", { length: 120 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    packageCptUnique: uniqueIndex("parcel_events_package_cpt_unique").on(table.packageCode, table.cptAt),
    cptIndex: index("parcel_events_cpt_idx").on(table.cptAt),
    locationIndex: index("parcel_events_location_idx").on(table.location),
  }),
);

export type ParcelEvent = typeof parcelEvents.$inferSelect;
export type InsertParcelEvent = typeof parcelEvents.$inferInsert;
