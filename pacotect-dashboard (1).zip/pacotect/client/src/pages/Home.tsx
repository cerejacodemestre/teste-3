import { useEffect, useMemo, useState } from "react";
import { Activity, ArrowDownToLine, Check, ChevronDown, CircleHelp, Clock3, FilterX, Layers3, MapPin, Package, Radio } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, LabelList, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { ChartDatum, DashboardSummary, PackageRow, PeriodFilter, TimelineItem } from "@shared/dashboard";
import { getBrazilDateKey, normalizeCptDateTime, shiftDateKey } from "@shared/cpt";
import { trpc } from "@/lib/trpc";

const DEMO_CPT = "2026-10-27 20:00";
const CPT_COUNTS = [
  ["2026-10-27 03:00", 1, 1],
  ["2026-10-27 10:00", 16, 15],
  ["2026-10-27 11:00", 1, 1],
  ["2026-10-27 12:00", 4, 2],
  ["2026-10-27 14:00", 1, 1],
  ["2026-10-27 18:00", 1, 1],
  ["2026-10-27 20:00", 15, 7],
  ["2026-10-27 21:00", 5, 5],
  ["2026-10-27 22:00", 554, 55],
] as const;
const LOCATIONS = ["BA1-2-13", "BA1-2-14", "SO2-1-47", "BA3-1-24"];
const STAGES = ["Esteira de Pequenos Volumes", "Esteira de Volumosos", "Em doca", "Armazenagem", "Expedição"];
const CHANNELS = ["SSP10", "SSP11", "REC06"];
const numberFormat = new Intl.NumberFormat("pt-BR");

function createDemoPackages(): PackageRow[] {
  const rows: PackageRow[] = [];
  for (const [cptAt, packageCount, huCount] of CPT_COUNTS) {
    const hour = cptAt.slice(11, 13);
    for (let i = 0; i < packageCount; i += 1) {
      const locationIndex = hour === "20" ? (i < 8 ? 0 : i < 12 ? 1 : i < 14 ? 2 : 3) : i % LOCATIONS.length;
      const stageIndex = hour === "20" ? (i < 4 ? 0 : i < 8 ? 1 : i < 12 ? 2 : i < 14 ? 3 : 4) : i % STAGES.length;
      rows.push({
        packageCode: `PKG-${hour}-${String(i + 1).padStart(3, "0")}`,
        huCode: `HU-${hour}-${String(Math.floor((i * huCount) / packageCount) + 1).padStart(2, "0")}`,
        cptAt,
        location: LOCATIONS[locationIndex],
        channel: hour === "20" ? "SSP10" : CHANNELS[i % CHANNELS.length],
        stage: STAGES[stageIndex],
      });
    }
  }
  return rows;
}

const DEMO_PACKAGES = createDemoPackages();
const DEMO_OPTIONS = {
  locations: [...new Set(DEMO_PACKAGES.map((row) => row.location))].sort(),
  channels: [...new Set(DEMO_PACKAGES.map((row) => row.channel))].sort(),
  stages: [...new Set(DEMO_PACKAGES.map((row) => row.stage))].sort(),
};

function formatCpt(value: string) {
  const canonical = normalizeCptDateTime(value);
  if (!canonical) return value;
  const [datePart, timePart] = canonical.split(" ");
  const [year, month, day] = datePart.split("-").map(Number);
  const [hour, minute] = timePart.split(":").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day, hour, minute));
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "UTC" }).format(date);
}

function groupByName(rows: PackageRow[], key: "location" | "channel" | "stage"): ChartDatum[] {
  const groups = new Map<string, number>();
  rows.forEach((row) => groups.set(row[key], (groups.get(row[key]) ?? 0) + 1));
  return [...groups.entries()].map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
}

function makeDemoSummary(period: PeriodFilter, location: string, channel: string, stage: string, selectedCpt: string): DashboardSummary {
  const now = new Date();
  const today = getBrazilDateKey(now);
  const minDate = shiftDateKey(today, -6);
  const filtered = DEMO_PACKAGES.filter((row) => {
    const date = row.cptAt.slice(0, 10);
    if (period === "today" && date !== today) return false;
    if (period === "7d" && (date < minDate || date > today)) return false;
    if (location && row.location !== location) return false;
    if (channel && row.channel !== channel) return false;
    if (stage && row.stage !== stage) return false;
    return true;
  });

  const timelineMap = new Map<string, { packages: number; hus: Set<string> }>();
  filtered.forEach((row) => {
    const cptKey = `${row.cptAt.slice(0, 13)}:00`;
    const current = timelineMap.get(cptKey) ?? { packages: 0, hus: new Set<string>() };
    current.packages += 1;
    current.hus.add(row.huCode);
    timelineMap.set(cptKey, current);
  });
  const timeline: TimelineItem[] = [...timelineMap.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([cptKey, value]) => ({ cptKey, packages: value.packages, hus: value.hus.size }));
  const chartRows = selectedCpt === "__all__" ? filtered : filtered.filter((row) => row.cptAt.slice(0, 13) === selectedCpt.slice(0, 13));
  return {
    hasDatabaseData: true,
    hasAnyData: filtered.length > 0,
    totalPackages: filtered.length,
    totalHUs: new Set(filtered.map((row) => row.huCode)).size,
    timeline,
    byLocation: groupByName(chartRows, "location"),
    byChannel: groupByName(chartRows, "channel"),
    byStage: groupByName(chartRows, "stage"),
    options: DEMO_OPTIONS,
    recentPackages: [...chartRows].sort((a, b) => b.cptAt.localeCompare(a.cptAt) || b.packageCode.localeCompare(a.packageCode)).slice(0, 8),
  };
}

function ChartCard({ eyebrow, title, caption, data, color = "orange", onSelect, compactLabels = false }: { eyebrow: string; title: string; caption: string; data: ChartDatum[]; color?: "orange" | "slate"; onSelect?: (name: string) => void; compactLabels?: boolean }) {
  const fill = color === "orange" ? "#f97316" : "#475569";
  return (
    <section className="chart-card">
      <div className="chart-heading">
        <div>
          <p className="section-eyebrow">{eyebrow}</p>
          <h2>{title}</h2>
        </div>
        <span className="chart-total">{numberFormat.format(data.reduce((sum, item) => sum + item.count, 0))}<small> pacotes</small></span>
      </div>
      <p className="chart-caption">{caption}</p>
      {data.length ? (
        <div className="chart-area">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 20, right: 12, left: -18, bottom: 0 }} barCategoryGap="30%" onClick={(state) => {
              const name = (state as { activePayload?: Array<{ payload?: ChartDatum }> } | null)?.activePayload?.[0]?.payload?.name;
              if (name) onSelect?.(name);
            }}>
              <CartesianGrid vertical={false} stroke="#e4e7e3" strokeDasharray="3 4" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={compactLabels ? <StageAxisTick /> : { fill: "#626c69", fontSize: 11, fontWeight: 600 }} interval={0} height={compactLabels ? 42 : 28} />
              <YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: "#89918e", fontSize: 10 }} width={34} />
              <Tooltip cursor={{ fill: "rgba(249,115,22,.06)" }} contentStyle={{ border: "1px solid #e3e6e0", borderRadius: 8, fontSize: 12, boxShadow: "0 8px 20px rgba(20,30,20,.08)" }} formatter={(value) => [`${numberFormat.format(Number(value))} pacotes`, "Volume"]} />
              <Bar dataKey="count" radius={[4, 4, 0, 0]} maxBarSize={72} onClick={(entry) => onSelect?.(entry.name)}>
                <LabelList dataKey="count" position="top" fill="#29312d" fontSize={12} fontWeight={700} />
                {data.map((entry, index) => <Cell key={entry.name} fill={index === 0 ? fill : color === "orange" ? "#fbbf24" : "#94a3b8"} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : <div className="chart-empty">Sem volumes para os filtros atuais.</div>}
    </section>
  );
}

function StageAxisTick({ x = 0, y = 0, payload }: { x?: number; y?: number; payload?: { value?: unknown } }) {
  const label = String(payload?.value ?? "");
  const lines = label === "Esteira de Pequenos Volumes"
    ? ["Esteira de", "Pequenos", "Volumes"]
    : label === "Esteira de Volumosos"
      ? ["Esteira de", "Volumosos"]
      : label === "Armazenagem"
        ? ["Armaz."]
      : [label];

  return (
    <g transform={`translate(${x},${y})`}>
      <text textAnchor="middle" fill="#626c69" fontSize={9} fontWeight={600}>
        {lines.map((line, index) => <tspan key={`${label}-${index}`} x={0} dy={index === 0 ? 0 : 10}>{line}</tspan>)}
      </text>
    </g>
  );
}

function StageBadge({ stage }: { stage: string }) {
  const tone = stage.toLocaleLowerCase("pt-BR").includes("expedi") ? "badge-green" : stage.toLocaleLowerCase("pt-BR").includes("doca") ? "badge-blue" : stage.toLocaleLowerCase("pt-BR").includes("armazen") ? "badge-gray" : "badge-orange";
  return <span className={`stage-badge ${tone}`}><span />{stage}</span>;
}

export default function Home() {
  const [period, setPeriod] = useState<PeriodFilter>("all");
  const [locationFilter, setLocationFilter] = useState("");
  const [channelFilter, setChannelFilter] = useState("");
  const [stageFilter, setStageFilter] = useState("");
  const [selectedCpt, setSelectedCpt] = useState<string>(DEMO_CPT);
  const query = trpc.dashboard.summary.useQuery({
    period,
    location: locationFilter || undefined,
    channel: channelFilter || undefined,
    stage: stageFilter || undefined,
    selectedCpt: selectedCpt === "__all__" ? null : selectedCpt,
  }, { retry: false, refetchOnWindowFocus: false, staleTime: 15_000 });

  const demoSummary = useMemo(() => makeDemoSummary(period, locationFilter, channelFilter, stageFilter, selectedCpt), [period, locationFilter, channelFilter, stageFilter, selectedCpt]);
  const isDemo = Boolean(query.error) || !query.data?.hasDatabaseData;
  const summary = isDemo ? demoSummary : query.data;

  useEffect(() => {
    if (!query.data?.hasAnyData || selectedCpt === "__all__" || query.data.timeline.length === 0) return;
    const exists = query.data.timeline.some((item) => item.cptKey.slice(0, 13) === selectedCpt.slice(0, 13));
    if (!exists) setSelectedCpt(query.data.timeline[query.data.timeline.length - 1].cptKey);
  }, [query.data, selectedCpt]);

  const resetFilters = () => {
    setPeriod("all");
    setLocationFilter("");
    setChannelFilter("");
    setStageFilter("");
    setSelectedCpt("__all__");
  };

  const exportTimeline = () => {
    const lines = ["CPT,Pacotes,HUs", ...(summary?.timeline ?? []).map((item) => `"${item.cptKey}",${item.packages},${item.hus}`)];
    const blob = new Blob(["\uFEFF", lines.join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "cpt-pacotes.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  const cptOptions = summary?.timeline ?? [];
  const activeCptRow = cptOptions.find((item) => item.cptKey.slice(0, 13) === selectedCpt.slice(0, 13));
  const selectedScopeLabel = selectedCpt === "__all__" ? "Todo o período" : formatCpt(selectedCpt);
  const leadingLocation = summary?.byLocation[0];
  const activeFilterCount = [period !== "all", Boolean(locationFilter), Boolean(channelFilter), Boolean(stageFilter), selectedCpt !== "__all__"].filter(Boolean).length;
  const latestTime = new Intl.DateTimeFormat("pt-BR", { hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date());

  return (
    <div className="app-shell">
      <aside className="brand-rail" aria-label="Identidade do painel">
        <div className="brand-symbol"><MapPin size={22} strokeWidth={2.6} /><i /></div>
        <div className="rail-rule" />
        <div className="rail-status"><span className="live-dot" /><span>OPERAÇÃO</span></div>
        <div className="rail-bottom">CT<span>•</span>01</div>
      </aside>

      <div className="page-column">
        <header className="topbar">
          <div className="topbar-brand">
            <span className="brand-overline">CENTRAL DE DISTRIBUIÇÃO <b> / </b> CONTROL TOWER</span>
            <h1>Localização de pacotes</h1>
          </div>
          <div className="topbar-right">
            <div className={`data-state ${isDemo ? "demo-state" : "connected-state"}`}><span />{isDemo ? "Demonstração" : "Base operacional"}</div>
            <div className="updated-at"><Radio size={14} /><span>Visão atualizada às <b>{latestTime}</b></span></div>
          </div>
        </header>

        <main className="dashboard-content">
          <div className={`demo-notice ${isDemo ? "" : "notice-live"}`}>
            <span className="notice-icon">{isDemo ? <CircleHelp size={15} /> : <Check size={15} />}</span>
            <span>{isDemo ? (query.error ? "Amostra demonstrativa · a base não respondeu. Os dados abaixo não são reais." : "Amostra demonstrativa · aguardando conexão automática com a fonte de dados.") : "Dados sincronizados da base operacional · localização e volumes refletem os registros atuais."}</span>
          </div>

          <section className="filter-bar" aria-label="Filtros do painel">
            <div className="filter-intro"><span className="filter-icon"><Layers3 size={17} /></span><div><strong>Filtrar visão</strong><small>{activeFilterCount ? `${activeFilterCount} filtro(s) ativo(s)` : "Todos os pacotes"}</small></div></div>
            <label className="filter-control"><span>PERÍODO</span><div className="select-wrap"><select value={period} onChange={(event) => setPeriod(event.target.value as PeriodFilter)}><option value="all">Todo histórico</option><option value="7d">Últimos 7 dias</option><option value="today">Hoje</option></select><ChevronDown size={14} /></div></label>
            <label className="filter-control"><span>CPT / LOTE</span><div className="select-wrap"><select value={selectedCpt} onChange={(event) => setSelectedCpt(event.target.value)}><option value="__all__">Todos os CPTs</option>{cptOptions.map((item) => <option key={item.cptKey} value={item.cptKey}>{formatCpt(item.cptKey)} · {numberFormat.format(item.packages)} pacotes</option>)}</select><ChevronDown size={14} /></div></label>
            <label className="filter-control"><span>LOCALIZAÇÃO</span><div className="select-wrap"><select value={locationFilter} onChange={(event) => setLocationFilter(event.target.value)}><option value="">Todas</option>{summary?.options.locations.map((value) => <option key={value}>{value}</option>)}</select><ChevronDown size={14} /></div></label>
            <label className="filter-control"><span>CANALIZAÇÃO</span><div className="select-wrap"><select value={channelFilter} onChange={(event) => setChannelFilter(event.target.value)}><option value="">Todas</option>{summary?.options.channels.map((value) => <option key={value}>{value}</option>)}</select><ChevronDown size={14} /></div></label>
            <label className="filter-control"><span>ESTÁGIO</span><div className="select-wrap"><select value={stageFilter} onChange={(event) => setStageFilter(event.target.value)}><option value="">Todos</option>{summary?.options.stages.map((value) => <option key={value}>{value}</option>)}</select><ChevronDown size={14} /></div></label>
            <button className="clear-filters" type="button" onClick={resetFilters} title="Limpar todos os filtros"><FilterX size={16} /><span>Limpar</span></button>
          </section>

          <section className="metric-row" aria-label="Resumo operacional">
            <article className="metric-card metric-main"><div className="metric-icon orange-icon"><Package size={18} /></div><div className="metric-label">PACOTES NO PERÍODO</div><div className="metric-number">{numberFormat.format(summary?.totalPackages ?? 0)}</div><div className="metric-foot"><span className="metric-line" /> volume total filtrado</div></article>
            <article className="metric-card"><div className="metric-icon slate-icon"><Layers3 size={18} /></div><div className="metric-label">HUs NO PERÍODO</div><div className="metric-number">{numberFormat.format(summary?.totalHUs ?? 0)}</div><div className="metric-foot">unidades de manuseio</div></article>
            <article className="metric-card"><div className="metric-icon slate-icon"><Clock3 size={18} /></div><div className="metric-label">JANELAS DE CPT</div><div className="metric-number">{numberFormat.format(summary?.timeline.length ?? 0)}</div><div className="metric-foot">agrupadas por hora</div></article>
            <article className="metric-card priority-card"><div className="metric-icon orange-icon"><MapPin size={18} /></div><div className="metric-label">MAIOR CONCENTRAÇÃO</div><div className="priority-name">{leadingLocation?.name ?? "—"}</div><div className="metric-foot"><b>{numberFormat.format(leadingLocation?.count ?? 0)}</b> pacote(s) · {selectedScopeLabel}</div></article>
          </section>

          <div className="workspace-grid">
            <section className="panel-card cpt-panel">
              <div className="panel-header">
                <div><p className="section-eyebrow">01 / JANELAS DE OPERAÇÃO</p><h2>Pacotes por CPT</h2><p className="panel-description">Selecione uma janela para detalhar os endereços à direita.</p></div>
                <button type="button" className="icon-action" onClick={exportTimeline} title="Exportar resumo CPT em CSV"><ArrowDownToLine size={16} /></button>
              </div>
              <div className="table-wrap cpt-table-wrap">
                <table className="data-table cpt-table">
                  <thead><tr><th>CPT <span className="sort-mark">↓</span></th><th className="numeric">PACOTES</th><th className="numeric">HU</th></tr></thead>
                  <tbody>
                    {summary?.timeline.length ? summary.timeline.map((item) => {
                      const active = selectedCpt !== "__all__" && item.cptKey.slice(0, 13) === selectedCpt.slice(0, 13);
                      return <tr key={item.cptKey} className={active ? "selected-row" : ""} onClick={() => setSelectedCpt(item.cptKey)} aria-selected={active}>
                        <td><button className="cpt-row-button" type="button" onClick={() => setSelectedCpt(item.cptKey)}><span className="row-indicator" /><span>{formatCpt(item.cptKey)}</span></button></td>
                        <td className="numeric value-cell">{numberFormat.format(item.packages)}</td>
                        <td className="numeric value-cell">{numberFormat.format(item.hus)}</td>
                      </tr>;
                    }) : <tr><td colSpan={3} className="empty-table">Nenhum CPT encontrado. Ajuste os filtros.</td></tr>}
                  </tbody>
                  <tfoot><tr><td>Total geral</td><td className="numeric">{numberFormat.format(summary?.totalPackages ?? 0)}</td><td className="numeric">{numberFormat.format(summary?.totalHUs ?? 0)}</td></tr></tfoot>
                </table>
              </div>
              <div className="cpt-panel-foot"><span className="orange-mini-dot" />{activeCptRow ? `Lote ativo: ${formatCpt(activeCptRow.cptKey)}` : "Todos os lotes em foco"}<b>{numberFormat.format(activeCptRow?.packages ?? summary?.totalPackages ?? 0)} pacotes</b></div>
            </section>

            <section className="charts-column" aria-label="Gráficos operacionais">
              <div className="charts-topline"><div><p className="section-eyebrow">02 / DISTRIBUIÇÃO DO FLUXO</p><h2>Onde estão os pacotes?</h2></div><span className="scope-pill"><span />{selectedScopeLabel}</span></div>
              <ChartCard eyebrow="ENDEREÇO / POSIÇÃO" title="Pacotes por localização" caption="Concentração por endereço físico" data={summary?.byLocation ?? []} onSelect={(name) => setLocationFilter(name)} />
              <div className="chart-pair">
                <ChartCard eyebrow="ROTA OPERACIONAL" title="Canalizações" caption="Comparação entre fluxos" data={summary?.byChannel ?? []} color="slate" onSelect={(name) => setChannelFilter(name)} />
                <ChartCard eyebrow="STATUS DO PACOTE" title="Estágios" caption="Distribuição por etapa" data={summary?.byStage ?? []} color="orange" onSelect={(name) => setStageFilter(name)} compactLabels />
              </div>
            </section>
          </div>

          <section className="panel-card package-detail-panel">
            <div className="panel-header package-header">
              <div><p className="section-eyebrow">03 / RASTREABILIDADE</p><h2>Pacotes no lote selecionado</h2><p className="panel-description">Localização e etapa de cada pacote em <b>{selectedScopeLabel}</b>.</p></div>
              <div className="package-count"><MapPin size={14} />{numberFormat.format(summary?.recentPackages.length ?? 0)} registros exibidos</div>
            </div>
            <div className="table-wrap detail-table-wrap">
              <table className="data-table package-table">
                <thead><tr><th>IDENTIFICAÇÃO</th><th>CPT</th><th>LOCALIZAÇÃO</th><th>CANALIZAÇÃO</th><th>ESTÁGIO ATUAL</th></tr></thead>
                <tbody>
                  {(summary?.recentPackages ?? []).length ? summary!.recentPackages.map((row) => <tr key={`${row.packageCode}-${row.cptAt}`}><td><span className="package-code"><Package size={14} />{row.packageCode}</span></td><td>{formatCpt(row.cptAt.slice(0, 16))}</td><td><span className="location-tag"><MapPin size={13} />{row.location}</span></td><td><span className="channel-tag">{row.channel}</span></td><td><StageBadge stage={row.stage} /></td></tr>) : <tr><td colSpan={5} className="empty-table">Sem pacotes para os filtros selecionados.</td></tr>}
                </tbody>
              </table>
            </div>
            <div className="detail-foot"><span>Exibindo até 8 pacotes recentes deste escopo.</span><span><Check size={14} /> Localização vinculada ao registro</span></div>
          </section>

          <footer className="dashboard-footer"><span><b>CONTROL TOWER</b> <span className="footer-separator">/</span> Visibilidade para decisão operacional</span></footer>
        </main>
      </div>
    </div>
  );
}
