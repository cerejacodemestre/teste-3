import { and, asc, count, desc, eq, sql, type SQL } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertParcelEvent, InsertUser, parcelEvents, users } from "../drizzle/schema";
import type { DashboardFilterInput, DashboardSummary, ImportParcelRow } from "../shared/dashboard";
import { getBrazilDateKey, shiftDateKey } from "../shared/cpt";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the Drizzle instance so local tooling can run without a database.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

function whereOrUndefined(conditions: SQL[]) {
  return conditions.length ? and(...conditions) : undefined;
}

export async function getParcelDashboard(input: DashboardFilterInput): Promise<DashboardSummary | null> {
  const db = await getDb();
  if (!db) return null;

  const baseConditions: SQL[] = [];
  if (input.period === "today" || input.period === "7d") {
    const today = getBrazilDateKey();
    const startDay = input.period === "today" ? today : shiftDateKey(today, -6);
    const endDay = shiftDateKey(today, 1);
    const startAt = `${startDay} 00:00:00`;
    const endAt = `${endDay} 00:00:00`;
    baseConditions.push(sql`${parcelEvents.cptAt} >= ${startAt} AND ${parcelEvents.cptAt} < ${endAt}`);
  }
  if (input.location) baseConditions.push(eq(parcelEvents.location, input.location));
  if (input.channel) baseConditions.push(eq(parcelEvents.channel, input.channel));
  if (input.stage) baseConditions.push(eq(parcelEvents.stage, input.stage));

  const baseWhere = whereOrUndefined(baseConditions);
  const [totals, storedTotals] = await Promise.all([
    db.select({ packages: count(), hus: sql<number>`COUNT(DISTINCT ${parcelEvents.huCode})` }).from(parcelEvents).where(baseWhere),
    db.select({ packages: count() }).from(parcelEvents),
  ]);
  const cptHour = sql<string>`CONCAT(SUBSTRING(${parcelEvents.cptAt}, 1, 13), ':00')`.as("cptKey");
  const timelineRows = await db
    .select({ cptKey: cptHour, packages: count(), hus: sql<number>`COUNT(DISTINCT ${parcelEvents.huCode})` })
    .from(parcelEvents)
    .where(baseWhere)
    .groupBy(sql`1`)
    .orderBy(sql`1`);

  const chartConditions = [...baseConditions];
  if (input.selectedCpt) chartConditions.push(sql`SUBSTRING(${parcelEvents.cptAt}, 1, 13) = ${input.selectedCpt.slice(0, 13)}`);
  const chartWhere = whereOrUndefined(chartConditions);
  const [locationRows, channelRows, stageRows, locationOptions, channelOptions, stageOptions, recentRows] = await Promise.all([
    db.select({ name: parcelEvents.location, count: count() }).from(parcelEvents).where(chartWhere).groupBy(parcelEvents.location).orderBy(desc(count())),
    db.select({ name: parcelEvents.channel, count: count() }).from(parcelEvents).where(chartWhere).groupBy(parcelEvents.channel).orderBy(desc(count())),
    db.select({ name: parcelEvents.stage, count: count() }).from(parcelEvents).where(chartWhere).groupBy(parcelEvents.stage).orderBy(desc(count())),
    db.selectDistinct({ value: parcelEvents.location }).from(parcelEvents).orderBy(asc(parcelEvents.location)),
    db.selectDistinct({ value: parcelEvents.channel }).from(parcelEvents).orderBy(asc(parcelEvents.channel)),
    db.selectDistinct({ value: parcelEvents.stage }).from(parcelEvents).orderBy(asc(parcelEvents.stage)),
    db.select({ packageCode: parcelEvents.packageCode, huCode: parcelEvents.huCode, cptAt: parcelEvents.cptAt, location: parcelEvents.location, channel: parcelEvents.channel, stage: parcelEvents.stage }).from(parcelEvents).where(chartWhere).orderBy(desc(parcelEvents.cptAt)).limit(8),
  ]);

  const toChart = (rows: Array<{ name: string; count: number }>) => rows.map((row) => ({ name: row.name, count: Number(row.count) }));
  return {
    hasDatabaseData: Number(storedTotals[0]?.packages ?? 0) > 0,
    hasAnyData: Number(totals[0]?.packages ?? 0) > 0,
    totalPackages: Number(totals[0]?.packages ?? 0),
    totalHUs: Number(totals[0]?.hus ?? 0),
    timeline: timelineRows.map((row) => ({ cptKey: row.cptKey, packages: Number(row.packages), hus: Number(row.hus) })),
    byLocation: toChart(locationRows),
    byChannel: toChart(channelRows),
    byStage: toChart(stageRows),
    options: { locations: locationOptions.map((row) => row.value), channels: channelOptions.map((row) => row.value), stages: stageOptions.map((row) => row.value) },
    recentPackages: recentRows,
  };
}

export async function importParcelEvents(rows: ImportParcelRow[]) {
  const db = await getDb();
  if (!db) throw new Error("Banco operacional indisponível.");
  const values: InsertParcelEvent[] = rows.map((row) => ({
    packageCode: row.packageCode.trim(),
    huCode: row.huCode.trim(),
    cptAt: row.cptAt.trim(),
    location: row.location.trim(),
    channel: row.channel.trim(),
    stage: row.stage.trim(),
  }));
  await db.insert(parcelEvents).values(values).onDuplicateKeyUpdate({
    set: {
      huCode: sql`VALUES(huCode)`,
      location: sql`VALUES(location)`,
      channel: sql`VALUES(channel)`,
      stage: sql`VALUES(stage)`,
    },
  });
  return { processed: rows.length };
}
