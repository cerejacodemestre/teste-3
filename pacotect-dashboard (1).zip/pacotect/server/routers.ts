import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { isValidCptTimestamp } from "../shared/cpt";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getParcelDashboard, importParcelEvents } from "./db";

const parcelRow = z.object({
  packageCode: z.string().trim().min(1).max(120),
  huCode: z.string().trim().min(1).max(120),
  cptAt: z.string().refine(isValidCptTimestamp, "Data/hora CPT inválida."),
  location: z.string().trim().min(1).max(120),
  channel: z.string().trim().min(1).max(120),
  stage: z.string().trim().min(1).max(120),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    summary: protectedProcedure
      .input(z.object({
        period: z.enum(["today", "7d", "all"]).default("all"),
        location: z.string().optional(),
        channel: z.string().optional(),
        stage: z.string().optional(),
        selectedCpt: z.string().nullable().optional(),
      }))
      .query(({ input }) => getParcelDashboard(input)),
    importCsv: protectedProcedure
      .input(z.object({ rows: z.array(parcelRow).min(1).max(5000) }))
      .mutation(({ input }) => importParcelEvents(input.rows)),
  }),
});

export type AppRouter = typeof appRouter;
