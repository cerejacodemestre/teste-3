# TODO — Control Tower de Pacotes

- [x] **Tabela operacional de CPT e filtros** — A tabela fica à esquerda em telas amplas e exibe CPT (data e hora), quantidade de pacotes e HU. Deve permitir refinar a visão por período/CPT.
- [x] **Gráficos de localização, canalização e estágio** — O painel contém gráficos de barras com pacotes por endereço ou localização, por canalização e por estágio operacional, com rótulos e valores visíveis e comparação rápida entre fluxos.
- [x] **Indicadores de resumo e priorização** — Exibir total de pacotes, total de HUs e principais concentrações; destacar visualmente localizações ou etapas com maior volume para facilitar a priorização operacional.
- [x] **Filtros e leitura responsiva da operação** — Permitir filtros por localização, canalização e estágio, além de período/CPT. A organização mantém tabela à esquerda e gráficos à direita em telas amplas e boa leitura em telas menores, com informação visível e fácil para a operação entender. Os períodos relativos usam o calendário de São Paulo.
- [x] **Base operacional persistente** — Armazenar registros de CPT, pacotes, HUs, endereços, canalizações e estágios para alimentar o painel com histórico confiável.
- [x] **Acesso autenticado aos dados operacionais** — Exigir sessão Manus válida para consultar o resumo ou importar pacotes, bloqueando chamadas anônimas.
- [x] **Interface sem importação manual** — Remover o botão de importar, o atalho para baixar modelo CSV e as instruções de envio; a amostra demonstrativa informa que aguarda a conexão automática da fonte de dados.
- [x] **Separação em duas categorias de esteira** — Representar “Separação” como “Esteira de Pequenos Volumes” e “Esteira de Volumosos” no gráfico, nos filtros e na amostra demonstrativa.
- [x] **Rótulos sem sobreposição em tela estreita** — No gráfico de estágios com largura próxima a 361 px, quebrar nomes longos em linhas para que “Esteira de Pequenos Volumes” e “Esteira de Volumosos” não se sobreponham; manter os nomes completos nos filtros e no tooltip.
- [ ] **Alimentação automática futura** — Conectar os dados operacionais automaticamente quando a fonte e as regras de sincronização forem definidas, incluindo a regra ou o campo que classifica os pacotes como pequenos volumes ou volumosos.
