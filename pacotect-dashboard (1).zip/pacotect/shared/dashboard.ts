export type PeriodFilter = "today" | "7d" | "all";

export type DashboardFilterInput = {
  period: PeriodFilter;
  location?: string;
  channel?: string;
  stage?: string;
  selectedCpt?: string | null;
};

export type TimelineItem = {
  cptKey: string;
  packages: number;
  hus: number;
};

export type ChartDatum = {
  name: string;
  count: number;
};

export type PackageRow = {
  packageCode: string;
  huCode: string;
  cptAt: string;
  location: string;
  channel: string;
  stage: string;
};

export type DashboardSummary = {
  hasDatabaseData: boolean;
  hasAnyData: boolean;
  totalPackages: number;
  totalHUs: number;
  timeline: TimelineItem[];
  byLocation: ChartDatum[];
  byChannel: ChartDatum[];
  byStage: ChartDatum[];
  options: {
    locations: string[];
    channels: string[];
    stages: string[];
  };
  recentPackages: PackageRow[];
};

export type ImportParcelRow = PackageRow;
