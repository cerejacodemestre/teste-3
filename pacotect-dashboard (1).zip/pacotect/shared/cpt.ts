export function isValidCptTimestamp(value: string): boolean {
  const match = value.match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/);
  if (!match) return false;
  return validParts(...match.slice(1).map(Number) as [number, number, number, number, number, number]);
}

export function normalizeCptDateTime(value: string): string | null {
  const input = value.trim();
  const brazilian = input.match(/^(\d{2})\/(\d{2})\/(\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?$/);
  if (brazilian) {
    const [, day, month, year, hour, minute, second = "00"] = brazilian;
    const parts = [Number(year), Number(month), Number(day), Number(hour), Number(minute), Number(second)] as const;
    if (!validParts(...parts)) return null;
    return `${year}-${month}-${day} ${hour.padStart(2, "0")}:${minute}:${second}`;
  }

  const iso = input.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?$/);
  if (!iso) return null;
  const [, year, month, day, hour, minute, second = "00"] = iso;
  const parts = [Number(year), Number(month), Number(day), Number(hour), Number(minute), Number(second)] as const;
  if (!validParts(...parts)) return null;
  return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
}

function validParts(year: number, month: number, day: number, hour: number, minute: number, second: number): boolean {
  if (year < 1 || year > 9999 || month < 1 || month > 12 || hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) return false;
  const leapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day >= 1 && day <= daysInMonth[month - 1];
}

export function getBrazilDateKey(date = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const year = parts.find((part) => part.type === "year")?.value ?? "0000";
  const month = parts.find((part) => part.type === "month")?.value ?? "00";
  const day = parts.find((part) => part.type === "day")?.value ?? "00";
  return `${year}-${month}-${day}`;
}

export function shiftDateKey(dateKey: string, offsetDays: number): string {
  const [year, month, day] = dateKey.split("-").map(Number);
  const shifted = new Date(Date.UTC(year, month - 1, day + offsetDays));
  return `${String(shifted.getUTCFullYear()).padStart(4, "0")}-${String(shifted.getUTCMonth() + 1).padStart(2, "0")}-${String(shifted.getUTCDate()).padStart(2, "0")}`;
}
